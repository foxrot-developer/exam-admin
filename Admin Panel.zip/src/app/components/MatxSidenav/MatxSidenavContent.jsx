import React from 'react'

const MatxSidenavContent = ({ children }) => {
    return <div className="relative flex-grow h-full">{children}</div>
}

export default MatxSidenavContent
