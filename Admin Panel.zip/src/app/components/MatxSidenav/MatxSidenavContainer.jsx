import React from 'react'

const MatxSidenavContainer = ({ children }) => {
    return <div className="relative flex h-full">{children}</div>
}

export default MatxSidenavContainer
